package com.cts.stockmarketcharting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cts.stockmarketcharting.entity.StockExchange;
import com.cts.stockmarketcharting.service.StockExchangeService;

@RestController
public class StockExchangeController {
	
	@Autowired
	StockExchangeService exchangeService;
	

	@RequestMapping(path="/exchange/{name}", method=RequestMethod.GET)
	public ResponseEntity<StockExchange> getExchangeByTitle(@PathVariable("name") String name){

		StockExchange exchangeFound =  exchangeService.findExchangeByName(name);
		ResponseEntity<StockExchange> status = null;
		if(exchangeFound==null){
			status = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		else{
	
			status = new ResponseEntity<>(exchangeFound,HttpStatus.OK);
			
		}
		System.out.println(exchangeFound);
		return status;

	}
	
	@RequestMapping(path="/exchanges", method=RequestMethod.GET)
	public List<StockExchange> getExchanges(){

		return exchangeService.findAll();
	}
	@RequestMapping(path="/exchange", method=RequestMethod.POST)
	public ResponseEntity<Void> addExchange(@RequestBody StockExchange exchange){
		System.out.println(exchange);
		exchangeService.save(exchange);
		ResponseEntity<Void> status = new ResponseEntity<>(HttpStatus.CREATED);
		return status;

		
	}

}

package com.cts.stockmarketcharting.service;

import java.util.List;
import com.cts.stockmarketcharting.entity.StockExchange;

public interface StockExchangeService {

	StockExchange findExchangeByName(String name);

	List<StockExchange> findAll();

	void save(StockExchange exchange);

}

package com.cts.stockmarketcharting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.cts.stockmarketcharting.service.StockPriceService;

@RestController
public class StockPriceController {
	
	@Autowired
	StockPriceService stockPrice;
	
	@PostMapping("/import")
	public void mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile) 
	{
		stockPrice.readFile(reapExcelDataFile);
          
   }
}



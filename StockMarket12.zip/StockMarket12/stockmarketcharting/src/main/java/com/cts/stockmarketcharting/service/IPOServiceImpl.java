package com.cts.stockmarketcharting.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.stockmarketcharting.entity.IPODetail;
import com.cts.stockmarketcharting.repos.IPORepo;


@Service
public class IPOServiceImpl implements IPOService{
	

	@Autowired
	IPORepo ipoRepo;

	@Override
	public List<IPODetail> findAllIPO() {
		
		return ipoRepo.findAll();
			
	}

	@Override
	public void save(IPODetail ipo) {
		ipoRepo.save(ipo);
	}

}
